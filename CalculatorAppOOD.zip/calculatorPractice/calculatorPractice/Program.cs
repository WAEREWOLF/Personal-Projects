﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculatorPractice
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            AdditionCommand addCommand = new AdditionCommand();
            SubstractionCommand subCommand = new SubstractionCommand();
            DivisionCommand divCommand = new DivisionCommand();
            MultiplyCommand multCommand = new MultiplyCommand();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1(addCommand,subCommand,divCommand,multCommand));

        }
    }
}
