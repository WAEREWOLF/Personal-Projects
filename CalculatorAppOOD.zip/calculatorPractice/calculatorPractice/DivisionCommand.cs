﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calculatorPractice
{
    class DivisionCommand : ICommand
    {
        public double Execute(double firstOpperand, double secondOpperand)
        {            
            return firstOpperand / secondOpperand;            
        }
    }
}
