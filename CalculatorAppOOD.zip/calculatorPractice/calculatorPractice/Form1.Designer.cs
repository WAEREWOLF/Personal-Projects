﻿namespace calculatorPractice
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstOperand = new System.Windows.Forms.TextBox();
            this.secondOperand = new System.Windows.Forms.TextBox();
            this.btnEqual = new System.Windows.Forms.Button();
            this.resultBox = new System.Windows.Forms.TextBox();
            this.rbAdd = new System.Windows.Forms.RadioButton();
            this.rbSubstract = new System.Windows.Forms.RadioButton();
            this.rbDivision = new System.Windows.Forms.RadioButton();
            this.rest = new System.Windows.Forms.TextBox();
            this.rbMultiply = new System.Windows.Forms.RadioButton();
            this.Clear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // firstOperand
            // 
            this.firstOperand.Location = new System.Drawing.Point(27, 68);
            this.firstOperand.Name = "firstOperand";
            this.firstOperand.Size = new System.Drawing.Size(100, 22);
            this.firstOperand.TabIndex = 0;
            // 
            // secondOperand
            // 
            this.secondOperand.Location = new System.Drawing.Point(291, 71);
            this.secondOperand.Name = "secondOperand";
            this.secondOperand.Size = new System.Drawing.Size(100, 22);
            this.secondOperand.TabIndex = 1;
            // 
            // btnEqual
            // 
            this.btnEqual.Location = new System.Drawing.Point(432, 68);
            this.btnEqual.Name = "btnEqual";
            this.btnEqual.Size = new System.Drawing.Size(75, 29);
            this.btnEqual.TabIndex = 2;
            this.btnEqual.Text = "=";
            this.btnEqual.UseVisualStyleBackColor = true;
            this.btnEqual.Click += new System.EventHandler(this.btnEqual_Click);
            // 
            // resultBox
            // 
            this.resultBox.Location = new System.Drawing.Point(549, 68);
            this.resultBox.Multiline = true;
            this.resultBox.Name = "resultBox";
            this.resultBox.ReadOnly = true;
            this.resultBox.Size = new System.Drawing.Size(100, 29);
            this.resultBox.TabIndex = 3;
            // 
            // rbAdd
            // 
            this.rbAdd.AutoSize = true;
            this.rbAdd.Checked = true;
            this.rbAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbAdd.Location = new System.Drawing.Point(169, 68);
            this.rbAdd.Name = "rbAdd";
            this.rbAdd.Size = new System.Drawing.Size(46, 29);
            this.rbAdd.TabIndex = 4;
            this.rbAdd.TabStop = true;
            this.rbAdd.Text = "+";
            this.rbAdd.UseVisualStyleBackColor = true;
            this.rbAdd.CheckedChanged += new System.EventHandler(this.rbAdd_CheckedChanged);
            // 
            // rbSubstract
            // 
            this.rbSubstract.AutoSize = true;
            this.rbSubstract.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbSubstract.Location = new System.Drawing.Point(232, 69);
            this.rbSubstract.Name = "rbSubstract";
            this.rbSubstract.Size = new System.Drawing.Size(41, 29);
            this.rbSubstract.TabIndex = 5;
            this.rbSubstract.Text = "-";
            this.rbSubstract.UseVisualStyleBackColor = true;
            this.rbSubstract.CheckedChanged += new System.EventHandler(this.rbSubstract_CheckedChanged);
            // 
            // rbDivision
            // 
            this.rbDivision.AutoSize = true;
            this.rbDivision.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbDivision.Location = new System.Drawing.Point(169, 103);
            this.rbDivision.Name = "rbDivision";
            this.rbDivision.Size = new System.Drawing.Size(40, 29);
            this.rbDivision.TabIndex = 6;
            this.rbDivision.TabStop = true;
            this.rbDivision.Text = "/";
            this.rbDivision.UseVisualStyleBackColor = true;
            this.rbDivision.CheckedChanged += new System.EventHandler(this.rbDivision_CheckedChanged);
            // 
            // rest
            // 
            this.rest.Location = new System.Drawing.Point(549, 119);
            this.rest.Multiline = true;
            this.rest.Name = "rest";
            this.rest.ReadOnly = true;
            this.rest.Size = new System.Drawing.Size(100, 29);
            this.rest.TabIndex = 7;
            this.rest.Visible = false;
            // 
            // rbMultiply
            // 
            this.rbMultiply.AutoSize = true;
            this.rbMultiply.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbMultiply.Location = new System.Drawing.Point(232, 104);
            this.rbMultiply.Name = "rbMultiply";
            this.rbMultiply.Size = new System.Drawing.Size(42, 29);
            this.rbMultiply.TabIndex = 8;
            this.rbMultiply.TabStop = true;
            this.rbMultiply.Text = "*";
            this.rbMultiply.UseVisualStyleBackColor = true;
            this.rbMultiply.CheckedChanged += new System.EventHandler(this.rbMultiply_CheckedChanged);
            // 
            // Clear
            // 
            this.Clear.Location = new System.Drawing.Point(432, 119);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(75, 29);
            this.Clear.TabIndex = 9;
            this.Clear.Text = "Clear";
            this.Clear.UseVisualStyleBackColor = true;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(681, 397);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.rbMultiply);
            this.Controls.Add(this.rest);
            this.Controls.Add(this.rbDivision);
            this.Controls.Add(this.rbSubstract);
            this.Controls.Add(this.rbAdd);
            this.Controls.Add(this.resultBox);
            this.Controls.Add(this.btnEqual);
            this.Controls.Add(this.secondOperand);
            this.Controls.Add(this.firstOperand);
            this.Name = "Form1";
            this.Text = "Simple Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox firstOperand;
        private System.Windows.Forms.TextBox secondOperand;
        private System.Windows.Forms.Button btnEqual;
        private System.Windows.Forms.TextBox resultBox;
        private System.Windows.Forms.RadioButton rbAdd;
        private System.Windows.Forms.RadioButton rbSubstract;
        private System.Windows.Forms.RadioButton rbDivision;
        private System.Windows.Forms.TextBox rest;
        private System.Windows.Forms.RadioButton rbMultiply;
        private System.Windows.Forms.Button Clear;
    }
}

