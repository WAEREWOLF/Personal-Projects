﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculatorPractice
{
    public interface ICommand
    {
      double Execute(double firstOpperand, double secondOpperand);
      
    }
}
