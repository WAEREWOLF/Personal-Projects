﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculatorPractice
{
    public partial class Form1 : Form
    {
        double firstNumber;
        double secondNumber;
        public static double restNumber;
        double result;
        //int rest1;
       
        private ICommand additionCommand;
        private ICommand substractionCommand;
        private ICommand divisionCommand;
        private ICommand multiplyCommand;
        ICommand currentCommand;

        public Form1(ICommand additionCommand, ICommand substractionCommand, ICommand divisionCommand, ICommand multiplyCommand)
        {
            InitializeComponent();
            this.additionCommand = additionCommand;
            this.substractionCommand = substractionCommand;
            this.divisionCommand = divisionCommand;
            this.multiplyCommand = multiplyCommand;
            currentCommand = additionCommand;             
        }

        private void btnEqual_Click(object sender, EventArgs e)
        {
            firstNumber = Convert.ToDouble(firstOperand.Text);
            secondNumber = Convert.ToDouble(secondOperand.Text);
                       
            result = currentCommand.Execute(firstNumber, secondNumber);            
            resultBox.Text = Convert.ToString(result);   
        }

        private void rbAdd_CheckedChanged(object sender, EventArgs e)
        {
            currentCommand = additionCommand;
        }

        private void rbSubstract_CheckedChanged(object sender, EventArgs e)
        {
            currentCommand = substractionCommand;            
        }

        private void rbDivision_CheckedChanged(object sender, EventArgs e)
        {
            currentCommand = divisionCommand;
            rest.Visible = true;
            if(rbDivision.Checked == false)
            {
                rest.Visible = false;
            }
        }

        private void rbMultiply_CheckedChanged(object sender, EventArgs e)
        {
            currentCommand = multiplyCommand;
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            resultBox.Clear();
        }
    }
}
