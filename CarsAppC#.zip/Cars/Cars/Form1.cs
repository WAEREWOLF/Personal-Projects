﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cars
{
    public partial class Form1 : Form
    {
        List<string> imagesList;
        List<string> caroserieList;

        int pretFinal = 0;
        int pretMarca = 0;
        int pretCaroserie = 0;
        int pretMotorizare = 0;
        int pretOptiuni = 0;

        

        public Form1()
        {
            InitializeComponent();
            imagesList = new List<string>();
            caroserieList = new List<string>();
                        
            string audi = Path.Combine(@"E:\","Poze" , "cars", "download" + ".jpg");
            string bmw = Path.Combine(@"E:\", "Poze", "cars", "bmwx5" + ".jpg");
            string mercedes = Path.Combine(@"E:\", "Poze", "cars", "MERTAN" + ".jpg");
            string dacia = Path.Combine(@"E:\", "Poze", "cars", "dacia" + ".jpg");
            string ferrari = Path.Combine(@"E:\", "Poze", "cars", "maxresdefault" + ".jpg");
            string opel = Path.Combine(@"E:\", "Poze", "cars", "astrag" + ".jpg");
            
            imagesList.Add(audi);
            imagesList.Add(bmw);
            imagesList.Add(mercedes);
            imagesList.Add(dacia);
            imagesList.Add(ferrari);
            imagesList.Add(opel);

            string hatchback = Path.Combine(@"E:\", "Poze", "cars", "hatchback" + ".png");
            string coupe = Path.Combine(@"E:\", "Poze", "cars", "coupe" + ".png");
            string sedan = Path.Combine(@"E:\", "Poze", "cars", "sedan" + ".png");
            string breakk = Path.Combine(@"E:\", "Poze", "cars", "break" + ".png");

            caroserieList.Add(hatchback);
            caroserieList.Add(coupe);
            caroserieList.Add(sedan);
            caroserieList.Add(breakk);

        }

        private void button_ADD(object sender, EventArgs e)
        {
            
            if (comboBox1.SelectedIndex >= 0 && comboBox2.SelectedIndex >= 0 && comboBox3.SelectedIndex >= 0 && comboBox4.SelectedIndex >= 0)
            {
                int row = 0;
                dataGridView1.Rows.Add();
                row = dataGridView1.Rows.Count - 2;
                pretFinal = pretMarca + pretCaroserie + pretOptiuni + pretMotorizare;
                priceLabel.Text = Convert.ToString(pretFinal) + "$";

                dataGridView1["MARCA", row].Value = comboBox1.Text;
                dataGridView1["MOTOR", row].Value = comboBox2.Text;
                dataGridView1["CAROSERIE", row].Value = comboBox3.Text;
                dataGridView1["OPTIUNI", row].Value = comboBox4.Text;
                dataGridView1["PRET", row].Value = pretFinal;

                
            }
            else MessageBox.Show("Completati toate campurile!");

        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            priceLabel.Font = new Font("Arial", 20, FontStyle.Bold);
            
            if (comboBox1.SelectedIndex == 0)
            {

                pictureBox1.Image = Image.FromFile(imagesList[0]);
               pretMarca = 20000;
                
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                pictureBox1.Image = Image.FromFile(imagesList[1]);
                pretMarca = 18000;
                
            }
            else if (comboBox1.SelectedIndex == 2)
            {
                pictureBox1.Image = Image.FromFile(imagesList[2]);
                pretMarca = 30000;
            }
            else if (comboBox1.SelectedIndex == 3)
            {
                pictureBox1.Image = Image.FromFile(imagesList[3]);
                pretMarca = 10000;
            }
            else if(comboBox1.SelectedIndex == 4)
            {
                pictureBox1.Image = Image.FromFile(imagesList[4]);
                pretMarca = 30000;
            }
            else if(comboBox1.SelectedIndex == 5)
            {
                pictureBox1.Image = Image.FromFile(imagesList[5]);
                pretMarca = 19000;
            }

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void backgroundWorker2_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox3.SelectedIndex == 0)
            {
                caroserii.Image = Image.FromFile(caroserieList[0]);
                pretCaroserie = 2000;
            }else if(comboBox3.SelectedIndex == 1)
            {
                caroserii.Image = Image.FromFile(caroserieList[1]);
                pretCaroserie = 3000;
            }else if(comboBox3.SelectedIndex == 2)
            {
                caroserii.Image = Image.FromFile(caroserieList[2]);
                pretCaroserie = 4000;
            }else if(comboBox3.SelectedIndex == 3)
            {
                caroserii.Image = Image.FromFile(caroserieList[3]);
                pretCaroserie = 3500;
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
             
            if (dataGridView1.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow item in this.dataGridView1.SelectedRows)
                {
                    dataGridView1.Rows.RemoveAt(item.Index);
                }
            }
            else MessageBox.Show("Nothing selected!");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            pretFinal = pretMarca + pretCaroserie + pretMotorizare + pretOptiuni;
            priceLabel.Text = Convert.ToString(pretFinal)+"$";

        }

        private void caroserii_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox2.SelectedIndex)
            {
                case 0:
                    pretMotorizare = 500;
                    break;
                case 1:
                    pretMotorizare = 1000;
                    break;
                case 2:
                    pretMotorizare = 1500;
                    break;
                case 3:
                    pretMotorizare = 2000;
                    break;
                case 4:
                    pretMotorizare = 2500;
                    break;
                case 5:
                    pretMotorizare = 3000;
                    break;
                default:
                    MessageBox.Show("Error in motorizari");
                    break;
            }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox4.SelectedIndex)
            {
                case 0:
                    pretOptiuni = 500;
                    break;
                case 1:
                    pretOptiuni = 1000;
                    break;
                case 2:
                    pretOptiuni = 1500;
                    break;
                case 3:
                    pretOptiuni = 2000;
                    break;
                case 4:
                    pretOptiuni = 2500;
                    break;
                case 5:
                    pretOptiuni = 3000;
                    break;
                default:
                    MessageBox.Show("Error in OPTIUNI!");
                    break;
            }
          }
             
       
    }
}
