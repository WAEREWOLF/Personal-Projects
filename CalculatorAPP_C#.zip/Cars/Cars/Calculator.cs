﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cars
{
    public partial class Calculator : Form
    {
        bool occurs;
        double firstOperand;
        double secondOperand;
        double result;
        string operation;


        public Calculator()
        {
            InitializeComponent();
            Display.Font = new Font("Arial", 16, FontStyle.Bold);
            occurs = false;
            operation = "";

        }
        
        private void button7_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text + "8";
        }

        private void button_Calculator(object sender, EventArgs e)
        {
            Display.Text = Display.Text + "5";
        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_1(object sender, EventArgs e)
        {
            Display.Text = Display.Text + "1";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text + "2";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text + "3";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text + "4";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text + "6";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text + "7";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text + "9";
        }

        private void Display_TextChanged(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            Display.Text = Display.Text + "0";
        }

        private void btn_C(object sender, EventArgs e)
        {
            Display.Clear();
            Display2.Clear();
            operation = "";
        }

        
        private void btn_Dot(object sender, EventArgs e)
        {
           
            if (Display.Text == "/" || Display.Text == "*" || Display.Text == "+" || Display.Text == "-")
                MessageBox.Show("Input a number first!");
            else 
                if (Display.Text == "")
                {
                Display.Text = Display.Text + "0.";
                occurs = true;
                }
            else {
                if (occurs == false)
                {
                    Display.Text = Display.Text + ".";
                    occurs = true;
                }
             }
            
        }

        private void btn_Divide(object sender, EventArgs e)
        {
            if (Display.Text == "")
            {
                Display2.Text = Display2.Text + "0 /";
               // operation = "/";
                firstOperand = 0;
            }
            else
            {
                firstOperand = Convert.ToDouble(Display.Text);
                Display2.Text = Display2.Text + Display.Text + " /";
                occurs = false;
                operation = "/";
                Display.Text = "";
            }
        }

        private void btn_Multiply(object sender, EventArgs e)
        {
            if (Display.Text == "")
            {
                Display2.Text = Display2.Text + "0 *";
                firstOperand = 0;
            }
            else
            {
                firstOperand = Convert.ToDouble(Display.Text);
                Display2.Text = Display2.Text + Display.Text + " *";
                occurs = false;
                operation = "*";
                Display.Text = "";
            }
        }

        private void operatie(Boolean clear = true)
        {
            if (clear)
            {
                Display2.Clear();
            }
            else
            {
                Display2.Text = Display2.Text + Display.Text + operation;
                Display.Clear();
            }
            switch (operation)
            {
                case "/":
                    secondOperand = Convert.ToDouble(Display.Text);
                    if (secondOperand != 0)
                        result = firstOperand / secondOperand;
                    else
                    {
                        MessageBox.Show("Cannot divide by Zero!");
                    }
                    Display.Text = Convert.ToString(result);
                    break;
                case "*":
                    secondOperand = Convert.ToDouble(Display.Text);
                    result = firstOperand * secondOperand;
                    Display.Text = Convert.ToString(result);
                    break;
                case "+":
                    
                    if (clear)
                    {
                        secondOperand = Convert.ToDouble(Display.Text);
                        result = firstOperand + secondOperand;
                        Display.Text = Convert.ToString(result);
                    }
                    else
                    {
                        result = firstOperand + secondOperand;
                        firstOperand = result;
                    }
                    break;
                case "-":
                   
                    secondOperand = Convert.ToDouble(Display.Text);
                    if (firstOperand < secondOperand)
                    {
                        result = secondOperand - firstOperand;
                        Display.Text = "- " + Convert.ToString(result);
                    }
                    else
                    {
                        result = firstOperand - secondOperand;
                        Display.Text = Convert.ToString(result);
                    }

                    break;
                    

            }
            
        }

        private void btn_Equal(object sender, EventArgs e)
        {
            operatie();
        }

        private void Display2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_Add(object sender, EventArgs e)
        {
            if (operation != "")
            {
                secondOperand = Convert.ToDouble(Display.Text);
                operatie(false);
            }
            else
            {

                if (Display.Text == "")
                {
                    Display2.Text = Display2.Text + "0 +";
                    firstOperand = 0;
                }
                else
                {
                    firstOperand = Convert.ToDouble(Display.Text);
                    Display2.Text = Display2.Text + Display.Text + " +";
                    occurs = false;
                    operation = "+";
                    //Display.Text = "";
                }
                Display.Clear();
            }
        }

        private void btn_Substraction(object sender, EventArgs e)
        {

            if (Display.Text == "")
            {
                Display2.Text = Display2.Text + "0 -";
                firstOperand = 0;
            }
            else
            {
                firstOperand = Convert.ToDouble(Display.Text);
                Display2.Text = Display2.Text + Display.Text + " -";
                occurs = false;
                operation = "-";
                Display.Text = "";
            }
            
        }

        private void btn_CE(object sender, EventArgs e)
        {
            if(Display.Text != "")
            {
              Display.Text = Display.Text.Substring(0, Display.Text.Length - 1);
            }           

        }

        private void btn_square(object sender, EventArgs e)
        {
            if(Display.Text == "")
            {
                MessageBox.Show("Input a number first!");
            }
            else
            {
                firstOperand = Convert.ToDouble(Display.Text);
                Display2.Text = Display2.Text + Display.Text + " ²";
                occurs = false;
                result = firstOperand * firstOperand;
                Display.Text = Convert.ToString(result);
            }
            
        }

        private void btn_Radical(object sender, EventArgs e)
        {
            if (Display.Text == "")
            {
                MessageBox.Show("Input a number first!");
            }
            else
            {
                firstOperand = Convert.ToDouble(Display.Text);
                Display2.Text = Display2.Text + Display.Text + " √";
                occurs = false;
                result = Math.Sqrt(firstOperand);
                Display.Text = Convert.ToString(result);
            }
            
        }
    }

    
}
