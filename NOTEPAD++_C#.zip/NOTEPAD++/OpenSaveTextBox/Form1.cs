﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using TextEditor;
using System.Text.RegularExpressions;
using MySql.Data.MySqlClient;

namespace OpenSaveTextBox
{
    public partial class Form1 : Form
    {
        RichTextBox richtextbox;
        RichTextBox linetextbox;
        RichTextBox rtbTab;
        public RichTextBox rtb;
        

        DataTable dataTable = new DataTable();        
        RichTextBox richTextBox;

        private Point _imageLocation = new Point(13, 5);
        private Point _imgHitArea = new Point(13, 2);

        MySqlConnection con = new MySqlConnection("server=localhost;user=root;password=gaga;database=data");

        Image CloseImage;

        public const int MAXCHARACTERS = 750;
        Dictionary<String, TabPage> files;
        Dictionary<RichTextBox, UndoRedoStack> undoRedo;
        Color bkOldColor = Color.Yellow;
        OpenFileDialog open = new OpenFileDialog();
        string fullPath;

        public string GetOpenFile()
        {
            return fullPath = Path.GetFullPath(open.FileName);
        }

        public Form1()
        {
            //undoRedo = new UndoRedo();

            this.FormBorderStyle = FormBorderStyle.Sizable;
            InitializeComponent();
            txtArea.Font = new Font("Courier new", 10);
            myListBox.Visible = false;
            closeListBoxToolStripMenuItem.Visible = false;
            files = new Dictionary<string, TabPage>();
            undoRedo = new Dictionary<RichTextBox, UndoRedoStack>();
            undoRedo.Add(txtArea, new UndoRedoStack(txtArea));
           // undoRedo.Add(rtb, new UndoRedoStack(rtb));
        }

        private void FontSizeMenu_Click(object sender, EventArgs e)
        {
            FontDialog fontSize = new FontDialog();

            if (fontSize.ShowDialog() == DialogResult.OK)
            {
                txtArea.Font = fontSize.Font;
            }
        }

        private void FontColorMenu_Click(object sender, EventArgs e)
        {
            ColorDialog fontColor = new ColorDialog();

            fontColor.ShowDialog();
            //txtArea.SelectionColor = fontColor.Color;
            txtArea.ForeColor = fontColor.Color;
        }

        private void NewFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //txtArea.Text = "";
            int index = 1;
            List<string> keys = new List<string>();
            foreach (string key in files.Keys)
            {
                if (key.StartsWith("Main") || key.StartsWith("New"))
                {
                    keys.Add(key);
                }
            }
            if (keys.Count == 0)
            {
                index = 0;
            }
            else if (keys.Count == 1)
            {
                index = 1;
            }
            else
            {
                keys.Sort();
                index = 1;
                foreach (string s in keys)
                {
                    string resultString = Regex.Match(s, @"\d+").Value;
                    if (resultString.Length == 0)
                        continue;
                    int val = Int32.Parse(resultString);
                    if (val > index)
                    {
                        break;
                    }
                    else if (val == index)
                    {
                        index++;
                    }
                }
            }            
            TabPage first = tabControl.TabPages[0];
            RichTextBox txt = first.Controls[0] as RichTextBox;
            RichTextBox txt2 = first.Controls[1] as RichTextBox;
            TabPage page = new TabPage();
            rtb = new RichTextBox();
            RichTextBox rtb2 = new RichTextBox();

            page.Bounds = first.Bounds;
            rtb.Bounds = txt.Bounds;
            rtb2.Bounds = txt2.Bounds;
            richtextbox = rtb;
            linetextbox = rtb2;
            rtb2.ScrollBars = 0;

            rtb.FontChanged += TxtArea_FontChangedTabs;
            rtb.SelectionChanged += TxtArea_SelectionChangedTabs;
            rtb.TextChanged += txtArea_TextChangedTabs; 
            rtb.MouseUp += contextTabs;
            rtb.VScroll += TxtArea_VScrollTabs;

            page.Controls.Add(rtb);
            page.Controls.Add(rtb2);

            string title = index == 0 ? "New" : ("New " + index);

            page.Text = title;
            rtb.Text = "";
            files[title] = page;
            tabControl.TabPages.Add(page);
            tabControl.SelectedTab = page;

            rtbTab = rtb;
            rtbTab.Font = new Font("Courier new", 10);

            
        }

        private void OpenFileMenu_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "(*.txt)|*.txt";

            DialogResult res = ofd.ShowDialog(this);

            if (res == DialogResult.OK && ofd.FileName.Length > 0)
            {
                string file = ofd.FileName;

                if (files.ContainsKey(file))
                {
                    TabPage page = files[file];
                    RichTextBox rtb = page.Controls[0] as RichTextBox;
                    rtb.Text = File.ReadAllText(file);
                    tabControl.SelectedTab = page;
                }
                else
                {
                    TabPage first = tabControl.TabPages[0];
                    RichTextBox txt = first.Controls[0] as RichTextBox;
                    RichTextBox txt2 = first.Controls[1] as RichTextBox;
                    if (txt.TextLength == 0 && first.Text == "New")
                    {
                        FileInfo info = new FileInfo(file);
                        first.Text = info.Name;
                        txt.Text = File.ReadAllText(file);
                        files.Remove("New");
                        files[file] = first;
                        tabControl.SelectedTab = first;
                        
                    }
                    else
                    {
                        TabPage page = new TabPage();
                        RichTextBox rtb = new RichTextBox();
                        RichTextBox rtb2 = new RichTextBox();
                        page.Bounds = first.Bounds;
                        rtb.Bounds = txt.Bounds;
                        rtb2.Bounds = txt2.Bounds;
                        rtb2.ScrollBars = 0;
                        richtextbox = rtb;
                        linetextbox = rtb2;
                        rtb.SelectionChanged += TxtArea_SelectionChangedTabs;
                        rtb.TextChanged += txtArea_TextChangedTabs;
                        rtb.VScroll += TxtArea_VScrollTabs;
                        rtb.FontChanged += TxtArea_FontChangedTabs;
                        //rtb.MouseClick += contextTabs;
                        page.Controls.Add(rtb);
                        page.Controls.Add(rtb2);
                        FileInfo info = new FileInfo(file);
                        page.Text = info.Name;
                        rtb.Text = File.ReadAllText(file);
                        files[file] = page;
                        tabControl.TabPages.Add(page);
                        tabControl.SelectedTab = page;
                        AddLineNumbersTabs();
                        
                    }
                }
                con.Open();

                string filename = Path.GetFileNameWithoutExtension(ofd.FileName) + ".txt";
                string pathname = Path.GetDirectoryName(ofd.FileName);
                string actionName = "Open";
                long characterLength = new System.IO.FileInfo(ofd.FileName).Length;
                string fileText = System.IO.File.ReadAllText(ofd.FileName);
                string username = LogIn.username;
                MySqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Insert into logs values('" + filename + "','" + pathname + "','" + characterLength.ToString() +"','"+ fileText +"','" + actionName + "','"+username +"')";
                cmd.ExecuteNonQuery();
                con.Close();
            }


        }

        private void SaveFileMenu_Click_1(object sender, EventArgs e)
        {
           
            TabPage crt = tabControl.SelectedTab;
            RichTextBox rtb = crt.Controls[0] as RichTextBox;
            string key = crt.Text;
            SaveFileDialog saveFileDialog1;
            foreach (string s in files.Keys)
            {
                if (files[s] == crt)
                {
                    key = s;
                    break;
                }
            }
            if (key.StartsWith("New") || key.StartsWith("Main") && !key.EndsWith(".txt"))
            {
                saveFileDialog1 = new SaveFileDialog();
                saveFileDialog1.Filter = "(*.txt)|*.txt";
                saveFileDialog1.Title = "Save a Text File";
                saveFileDialog1.ShowDialog();

                // If the file name is not an empty string open it for saving.  
                if (saveFileDialog1.FileName != "")
                {
                    if (files.ContainsKey(saveFileDialog1.FileName))
                    {
                        MessageBox.Show("This file already is open");
                        return;
                    }
                    // Saves the Image via a FileStream created by the OpenFile method.  
                    System.IO.FileStream fs = (System.IO.FileStream)saveFileDialog1.OpenFile();
                    byte[] bytes = Encoding.ASCII.GetBytes(rtb.Text);
                    fs.Write(bytes, 0, bytes.Length);
                    fs.Close();
                    FileInfo info = new FileInfo(saveFileDialog1.FileName);
                    crt.Text = info.Name;
                    files.Remove(key);
                    files[saveFileDialog1.FileName] = crt;
                    
                    con.Open();

                    string filename = Path.GetFileNameWithoutExtension(saveFileDialog1.FileName) + ".txt";
                    string pathname = Path.GetDirectoryName(saveFileDialog1.FileName);
                    string actionName = "Save";
                    long characterLength = new System.IO.FileInfo(saveFileDialog1.FileName).Length;
                    string fileText = System.IO.File.ReadAllText(saveFileDialog1.FileName);

                    MySqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "Insert into logs values('" + filename + "','" + pathname + "','" + characterLength.ToString() + "','" + fileText + "','" + actionName + "')";
                    cmd.ExecuteNonQuery();
                    con.Close();
                    
                }
            }
            else
            {
                File.WriteAllText(key, rtb.Text);
            }

            
        }

        private void FontSizeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FontDialog fontSize = new FontDialog();

            if (fontSize.ShowDialog() == DialogResult.OK)
            {
                txtArea.Font = fontSize.Font;
            }
        }

        private void FontColorToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ColorDialog fontColor = new ColorDialog();

            fontColor.ShowDialog();
           
            txtArea.ForeColor = fontColor.Color;
        }

        private void SearchFileMenu_Click(object sender, EventArgs e)
        {
            Search form2 = new Search(this);
            form2.Show();
        }

        private void Redo_Click(object sender, EventArgs e)
        {
            txtArea.Redo();
        }

        private void Undo_Click(object sender, EventArgs e)
        {
            txtArea.Undo();
        }

        private void CutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(txtArea.SelectedText);
            txtArea.SelectedText = string.Empty;
        }

        private void CopyToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {
                clipboard.Visible = true;

                if (tabControl.SelectedIndex > 0 && !clipboard.Items.Contains(rtbTab.SelectedText))
                {
                    Clipboard.SetText(rtbTab.SelectedText);

                    clipboard.Items.Add(rtbTab.SelectedText);
                }
                else if (!clipboard.Items.Contains(txtArea.SelectedText))
                {
                    Clipboard.SetText(txtArea.SelectedText);

                    if (txtArea.SelectedText != "")
                    {
                        clipboard.Items.Add(txtArea.SelectedText);
                    }
                }
            }
            catch (Exception)
            {

            }
        }

        private void CopyToolStripMenuItem1_Tabs(object sender, EventArgs e)
        {
            Clipboard.SetText(txtArea.SelectedText);
            Clipboard.SetText(txtArea.SelectedText);
            List<string> items = new List<string>();
            int count = 0;
            var lineNr = txtArea.Lines;
            foreach (var lineText in lineNr)
            {
                count++;
                if (lineText.Contains(txtArea.SelectedText))
                {
                    ClipboardHistory clip = new ClipboardHistory();
                    clip.countLineText = lineText;
                    clip.countLineNumber = count;
                    clipboard.Items.Add(clip);
                    items.Add(lineText);
                }
            }
        }

        private void PasteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            txtArea.SelectedText = "";

            string paste = Clipboard.GetText();

            try
            {

                if (clipboard.SelectedItem != null && txtArea.Focused)
                {
                    int i = txtArea.SelectionStart;
                    txtArea.Text = txtArea.Text.Insert(txtArea.SelectionStart, clipboard.SelectedItem.ToString());
                    txtArea.SelectionStart = i + clipboard.SelectedItem.ToString().Length;
                }
                else if (clipboard.SelectedItem == null && txtArea.Focused)
                {
                    int i = txtArea.SelectionStart;
                    txtArea.Text = txtArea.Text.Insert(txtArea.SelectionStart, paste);
                    txtArea.SelectionStart = i + Clipboard.GetText().Length;
                }

                if (clipboard.SelectedItem != null && rtbTab.Focused)
                {
                    int i = rtbTab.SelectionStart;
                    rtbTab.Text = txtArea.Text.Insert(rtbTab.SelectionStart, clipboard.SelectedItem.ToString());
                    rtbTab.SelectionStart = i + clipboard.SelectedItem.ToString().Length;
                }
                else if (clipboard.SelectedItem == null && rtbTab.Focused)
                {
                    int i = txtArea.SelectionStart;
                    rtbTab.Text = txtArea.Text.Insert(rtbTab.SelectionStart, paste);
                    rtbTab.SelectionStart = i + Clipboard.GetText().Length;
                }
            }
            catch (Exception)
            {

            }
        }

        private void ExitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        public int GetWidth()
        {
            int w = 15;

            int line = txtArea.Lines.Length;

            if (line <= 99)
            {
                w = 15 + (int)txtArea.Font.Size;
            }
            else if (line <= 999)
            {
                w = 25 + (int)txtArea.Font.Size;
            }
            else
            {
                w = 50 + (int)txtArea.Font.Size;
            }
            return w;
        }
        public int GetWidthTabs()
        {
            int w = 15;

            int line = richtextbox.Lines.Length;

            if (line <= 99)
            {
                w = 15 + (int)richtextbox.Font.Size;
            }
            else if (line <= 999)
            {
                w = 25 + (int)richtextbox.Font.Size;
            }
            else
            {
                w = 50 + (int)richtextbox.Font.Size;
            }
            return w;
        }

        public void AddLineNumbers()
        {
            Point pt = new Point(0, 0);
            int First_Index = txtArea.GetCharIndexFromPosition(pt);
            int First_Line = txtArea.GetLineFromCharIndex(First_Index);
            pt.X = ClientRectangle.Width;
            pt.Y = ClientRectangle.Height;
            int Last_Index = txtArea.GetCharIndexFromPosition(pt);
            int Last_Line = txtArea.GetLineFromCharIndex(Last_Index);
            lineNumberRichText.Font = txtArea.Font;
            
            lineNumberRichText.ReadOnly = true;
            lineNumberRichText.SelectionAlignment = HorizontalAlignment.Center;
            lineNumberRichText.Text = "";
            lineNumberRichText.Width = GetWidth();
            for (int i = First_Line; i <= Last_Line; i++)
            {
                lineNumberRichText.Text += i + 1 + "\n";
            }
        }
        public void AddLineNumbersTabs()
        {
            Point pt = new Point(0, 0);
            int First_Index = richtextbox.GetCharIndexFromPosition(pt);
            int First_Line = richtextbox.GetLineFromCharIndex(First_Index);
            pt.X = ClientRectangle.Width;
            pt.Y = ClientRectangle.Height;
            int Last_Index = richtextbox.GetCharIndexFromPosition(pt);
            int Last_Line = richtextbox.GetLineFromCharIndex(Last_Index);
            linetextbox.Font = richtextbox.Font;
            
            linetextbox.ReadOnly = true;
            linetextbox.SelectionAlignment = HorizontalAlignment.Center;
            linetextbox.Text = "";
            linetextbox.Width = GetWidthTabs();
            for (int i = First_Line; i <= Last_Line; i++)
            {
                linetextbox.Text += i + 1 + "\n";
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            lineNumberRichText.Font = txtArea.Font;
            txtArea.Select();
            AddLineNumbers();

            
            tabControl.DrawMode = TabDrawMode.OwnerDrawFixed;
            tabControl.DrawItem += tabControl_DrawItem;
            CloseImage = Properties.Resources.download2;
            tabControl.Padding = new Point(10, 3);

            //character panel
            dataTable.Columns.Add("Value", typeof(int));
            dataTable.Columns.Add("Hex", typeof(string));
            dataTable.Columns.Add("Character", typeof(string));
            
            dataGridView1.DataSource = dataTable;
            dataGridView1.ForeColor = Color.Red;
            for (int i = 0; i <= 255; i++)
            {
                string hex = Convert.ToString(i, 16);
                if (i <= 15)
                {
                    hex = "0" + Convert.ToString(i, 16);
                }
                char special = Convert.ToChar(i);
                if (i == 32)
                {
                    string x = "Space";
                    dataTable.Rows.Add(i, hex, x);

                }
                if (i == 9)
                {
                    string x = "Tab";
                    dataTable.Rows.Add(i, hex, x);

                }
                if (i == 10)
                {
                    string x = "LF";
                    dataTable.Rows.Add(i, hex, x);

                }

                if (i > 32 && (i < 127 || i > 160))

                {
                    dataTable.Rows.Add(i, hex, special);

                }

            }
            Show();
        }

        private void tabControl_DrawItem(object sender, System.Windows.Forms.DrawItemEventArgs e)
        {
            try
            {
                Image img = new Bitmap(CloseImage);
                Rectangle r = e.Bounds;
                r = this.tabControl.GetTabRect(e.Index);
                r.Offset(2, 2);
                Brush TitleBrush = new SolidBrush(Color.Black);
                Font f = this.Font;
                string title = this.tabControl.TabPages[e.Index].Text;

                e.Graphics.DrawString(title, f, TitleBrush, new PointF(r.X, r.Y));

                if (tabControl.SelectedIndex >= 1)
                {
                    e.Graphics.DrawImage(img, new Point(r.X + (this.tabControl.GetTabRect(e.Index).Width - _imageLocation.X), _imageLocation.Y));
                }
            }
            catch (Exception) { }
        }

        private void txtArea_TextChanged_1(object sender, EventArgs e)
        {
            if (txtArea.Text == "")
            {
                AddLineNumbers();
            }
           
            UndoRedoStack u = null;
            foreach (var x in undoRedo)
            {
                if (x.Key.Equals(tabControl.SelectedTab.Controls[0]))
                {
                    u = x.Value;
                }
            }
            int y = txtArea.SelectionStart;
            u.InsertText(txtArea.Text, y);
        }
        private void txtArea_TextChangedTabs(object sender, EventArgs e)
        {
            
            if (richtextbox.Text == "")
            {
                AddLineNumbersTabs();
            }
            if (richtextbox.Text.Length > MAXCHARACTERS - 1)
            {
                richtextbox.ReadOnly = true;
                MessageBox.Show("You can not enter any more characters.");
            }
            
        }
        private void TxtArea_SelectionChanged(object sender, EventArgs e)
        {
            Point pt = txtArea.GetPositionFromCharIndex(txtArea.SelectionStart);
            if (pt.X == 1)
            {
                AddLineNumbers();
            }
        }
        private void TxtArea_SelectionChangedTabs(object sender, EventArgs e)
        {
            Point pt = richtextbox.GetPositionFromCharIndex(richtextbox.SelectionStart);
            if (pt.X == 1)
            {
                AddLineNumbersTabs();
            }
        }

        private void TxtArea_VScroll(object sender, EventArgs e)
        {
            lineNumberRichText.Text = "";
            AddLineNumbers();
            lineNumberRichText.Invalidate();
        }
        private void TxtArea_VScrollTabs(object sender, EventArgs e)
        {
            linetextbox.Text = "";
            AddLineNumbersTabs();
            linetextbox.Invalidate();
        }

        private void TxtArea_FontChanged(object sender, EventArgs e)
        {
            lineNumberRichText.Font = txtArea.Font;
            txtArea.Select();
            AddLineNumbers();
        }
        private void TxtArea_FontChangedTabs(object sender, EventArgs e)
        {
            linetextbox.Font = richtextbox.Font;
            richtextbox.Select();
            AddLineNumbersTabs();
        }

        private void LineNumberRichText_MouseDown(object sender, MouseEventArgs e)
        {
            txtArea.Select();
            lineNumberRichText.DeselectAll();
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            AddLineNumbers();
        }

        private void TimeDateMenu_Click(object sender, EventArgs e)
        {
            txtArea.Text = DateTime.Now.ToString();
        }

        private void GoToToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3(this);
            form3.Show();
        }

        private void SelectAllToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            txtArea.SelectAll();
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            int charLeft = MAXCHARACTERS - txtArea.Text.Length;
            int index = txtArea.SelectionStart;

            if (txtArea.Text == "")
            {
                AddLineNumbers();
            }
        }

        private void DeleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtArea.SelectedText = "";
        }

        private void HelpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://notepad-plus-plus.org/resources.html");
        }

        public void SelectAll(RichTextBox richTextBox, string word, Color green, bool Bold)
        {
            richTextBox.Select(0, richTextBox.TextLength);
            richTextBox.SelectionBackColor = richTextBox.BackColor;
            richTextBox.SelectionFont = richTextBox.Font;

            if (word == "")
            {
                return;
            }

            int s_start = richTextBox.SelectionStart, startIndex = 0, index;

            while ((index = richTextBox.Text.IndexOf(word, startIndex)) != -1)
            {
                richTextBox.Select(index, word.Length);
                richTextBox.SelectionBackColor = green;
                richTextBox.SelectionFont = new Font(richTextBox.Font, FontStyle.Bold);
                startIndex = index + word.Length;
            }

            richTextBox.SelectionStart = s_start;
            richTextBox.SelectionLength = 0;
        }

        private void TxtArea_DoubleClick(object sender, EventArgs e)
        {
            if (myListBox.Visible == true)
            {
                return;
            }
            else
            {
                string word = txtArea.SelectedText;
                SelectAll(txtArea, word, Color.DarkSeaGreen, Font.Bold);
            }
        }
        private void TxtArea_DoubleClickTabs(object sender, EventArgs e)
        {
            if (myListBox.Visible == true)
            {
                return;
            }
            else
            {
                string word = richtextbox.SelectedText;
                SelectAll(richtextbox, word, Color.DarkSeaGreen, Font.Bold);
            }
        }
        private void RefreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string text = txtArea.Text;
            string lineNumber = lineNumberRichText.Text;
            txtArea.Clear();
            lineNumberRichText.Clear();
            txtArea.Text = text;
            lineNumberRichText.Text = lineNumber;
        }

        public void MyListBox_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            TabPage selectedTab1 = tabControl.SelectedTab;
            RichTextBox selectedRichTextBox1 = selectedTab1.Controls[0] as RichTextBox;
            selectedRichTextBox1.SelectionFont = selectedRichTextBox1.Font;
            SearchedItems lineList = myListBox.SelectedItem as SearchedItems;
            if (lineList != null)
            {
                string file = lineList.filePath;

                if (files.ContainsKey(file))
                {
                    TabPage page = files[file];
                    RichTextBox rtb = page.Controls[0] as RichTextBox;
                    rtb.Text = File.ReadAllText(file);
                    tabControl.SelectedTab = page;
                }
                else
                {
                    TabPage first = tabControl.TabPages[0];
                    RichTextBox txt = first.Controls[0] as RichTextBox;
                    RichTextBox txt2 = first.Controls[1] as RichTextBox;
                    if (txt.TextLength == 0 && first.Text == "New")
                    {
                        FileInfo info = new FileInfo(file);
                        first.Text = info.Name;
                        txt.Text = File.ReadAllText(file);
                        files.Remove("New");
                        files[file] = first;
                        tabControl.SelectedTab = first;
                    }
                    else
                    {
                        TabPage page = new TabPage();
                        RichTextBox rtb = new RichTextBox();
                        RichTextBox rtb2 = new RichTextBox();
                        page.Bounds = first.Bounds;
                        rtb.Bounds = txt.Bounds;
                        rtb2.Bounds = txt2.Bounds;
                        rtb2.ScrollBars = 0;
                        richtextbox = rtb;
                        linetextbox = rtb2;
                        rtb.SelectionChanged += TxtArea_SelectionChangedTabs;
                        rtb.TextChanged += txtArea_TextChangedTabs;
                        rtb.VScroll += TxtArea_VScrollTabs;
                        rtb.FontChanged += TxtArea_FontChangedTabs;
                        rtb.KeyDown += txtArea_KeyDown_Tabs;
                        page.Controls.Add(rtb);
                        page.Controls.Add(rtb2);
                        FileInfo info = new FileInfo(file);
                        page.Text = info.Name;
                        rtb.Text = File.ReadAllText(file);
                        files[file] = page;
                        tabControl.TabPages.Add(page);
                        tabControl.SelectedTab = page;
                    }
                }

                AddLineNumbersTabs();
                int lineNumber = lineList.LineNumber;
                TabPage selectedTab = tabControl.SelectedTab;
                RichTextBox selectedRichTextBox = selectedTab.Controls[0] as RichTextBox;
                int index = selectedRichTextBox.GetFirstCharIndexFromLine(lineNumber - 1);
                selectedRichTextBox.SelectionStart = selectedRichTextBox.GetFirstCharIndexFromLine(lineNumber - 1);
                selectedRichTextBox.SelectionLength = lineList.LineText.Count();               
                selectedRichTextBox.ScrollToCaret();
                selectedRichTextBox.Focus();                
            }
        }

        private void CloseListBoxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            myListBox.Visible = false;
            myListBox.Items.Clear();
            closeListBoxToolStripMenuItem.Visible = false;
            string text = txtArea.Text;
            string lineNumber = lineNumberRichText.Text;
            txtArea.Clear();
            lineNumberRichText.Clear();
            txtArea.Text = text;
            lineNumberRichText.Text = lineNumber;
        }

        private void FileSystemWatcher1_Changed(object sender, FileSystemEventArgs e)
        {
            fileSystemWatcher1.NotifyFilter = NotifyFilters.LastWrite;
            fileSystemWatcher1.Filter = "*.txt";
            fileSystemWatcher1.IncludeSubdirectories = true;
            fileSystemWatcher1.EnableRaisingEvents = true;
            RichTextChanged rich = new RichTextChanged(this);
            rich.Show();
        }

        private void serchInFolderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchInFolder asd = new SearchInFolder(myListBox);
        }

        private void uppercaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtArea.SelectedText = txtArea.SelectedText.ToUpper();
        }

        private void lowercaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtArea.SelectedText = txtArea.SelectedText.ToLower();
        }

        private void Context_Opening(object sender, CancelEventArgs e)
        {
            if (txtArea.SelectedText == "")
            {
                uppercaseToolStripMenuItem.Enabled = false;
                lowercaseToolStripMenuItem.Enabled = false;
            }
            else
            {
                uppercaseToolStripMenuItem.Enabled = true;
                lowercaseToolStripMenuItem.Enabled = true;
            }

        }

        private void fileSystemWatcher1_Deleted(object sender, FileSystemEventArgs e)
        {

        }

        private void tabControl_MouseClick(object sender, MouseEventArgs e)
        {            
            TabControl tc = (TabControl)sender;            
            Point p = e.Location;
            int _tabWidth = 0;
            _tabWidth = this.tabControl.GetTabRect(tc.SelectedIndex).Width - (_imgHitArea.X);
            Rectangle r = this.tabControl.GetTabRect(tc.SelectedIndex);
            r.Offset(_tabWidth, _imgHitArea.Y);
            r.Width = 16;
            r.Height = 16;
            if (tabControl.SelectedIndex >= 1)
            {
                if (r.Contains(p))
                {
                    TabPage TabP = (TabPage)tc.TabPages[tc.SelectedIndex];
                    

                    DialogResult dialogResult = MessageBox.Show("Are you sure?", "Message", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {
                        files.Remove(files.ElementAt(tc.SelectedIndex-1).Key);                        
                        if (tc.SelectedIndex > 1)
                            tc.SelectedIndex = tc.SelectedIndex - 1;
                        else 
                            tc.SelectedIndex = tc.SelectedIndex + 1;

                        tc.TabPages.Remove(TabP);
                    }
                }
            }
        }

        private void clipboard_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (tabControl.SelectedIndex > 0)
            {
                int j = rtbTab.SelectionStart;

                rtbTab.Text = rtbTab.Text.Insert(rtbTab.SelectionStart, clipboard.SelectedItem.ToString());
                rtbTab.SelectionStart = j + clipboard.SelectedItem.ToString().Length;
                rtbTab.Focus();
            }
            else
            {
                int i = txtArea.SelectionStart;

                txtArea.Text = txtArea.Text.Insert(txtArea.SelectionStart, clipboard.SelectedItem.ToString());
                txtArea.SelectionStart = i + clipboard.SelectedItem.ToString().Length;
                txtArea.Focus();
            }
        }
        private void contextTabs(object sender, MouseEventArgs e)
        {
            if(e.Button == MouseButtons.Right)
                this.Context.Show(this.tabControl, e.Location);
        }

        private void clearClipboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clipboard.Items.Clear();
        }

        private void clipboard_SelectedIndexChanged(object sender, EventArgs e)
        {
            Clipboard.SetText(clipboard.Text);
            
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control == true && e.KeyCode == Keys.C)
            {
                CopyToolStripMenuItem1_Click(null, null);
            }
            else
            if (e.Control == true && e.KeyCode == Keys.V)
            {
                PasteToolStripMenuItem1_Click(null, null);
            }
            else
            if (e.Control == true && e.KeyCode == Keys.U)
            {
                CutToolStripMenuItem1_Click(null, null);
            }
            else
            if (e.Control == true && e.KeyCode == Keys.D)
            {
                DeleteToolStripMenuItem_Click(null, null);
            }
            else
            if (e.Control == true && e.KeyCode == Keys.A)
            {
                SelectAllToolStripMenuItem1_Click(null, null);
            }
            else if (e.Control == true && e.KeyCode == Keys.Z)
            {
                UndoRedoStack u = null;
                foreach (var x in undoRedo)
                {
                    if (x.Key.Equals(tabControl.SelectedTab.Controls[0]))
                    {
                        u = x.Value;
                    }
                }
                u.Undo();
            }
            else if (e.Control == true && e.KeyCode == Keys.Y)
            {
                UndoRedoStack u = null;
                foreach (var x in undoRedo)
                {
                    if (x.Key.Equals(tabControl.SelectedTab.Controls[0]))
                    {
                        u = x.Value;
                    }
                }
                u.Redo();
            }
        }

        private void txtArea_KeyDown_Tabs(object sender, KeyEventArgs e)
        {
            
        }

        private void columnEditorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColumnEditor column = new ColumnEditor(this);
            column.Show();
        }

        private void characterPanelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var panel = tabControl.SelectedTab.Controls[0] as RichTextBox;
            CharacterPanel character = new CharacterPanel(tabControl, panel);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            bool visited = false;
            richTextBox = tabControl.SelectedTab.Controls[0] as RichTextBox;


            int p = richTextBox.SelectionStart;
            var element = dataTable.Rows[e.RowIndex]["Character"].ToString();
            int l = dataTable.Rows[e.RowIndex]["Character"].ToString().Length;
            if (element.Equals("Tab"))
            {
                richTextBox.Text = richTextBox.Text.Insert(richTextBox.SelectionStart, "  ");
                richTextBox.SelectionStart = p + 2;
                richTextBox.ScrollToCaret();
                richTextBox.Focus();
                visited = true;
            }
            if (element.Equals("LF"))
            {
                richTextBox.AppendText("\r\n");
                visited = true;
                richTextBox.ScrollToCaret();
                richTextBox.Focus();

            }
            if (element.Equals("Space"))
            {
                richTextBox.Text = richTextBox.Text.Insert(richTextBox.SelectionStart, " ");
                richTextBox.SelectionStart = p + 1;
                richTextBox.ScrollToCaret();
                richTextBox.Focus();
                visited = true;
            }
            if (!visited)
            {
                richTextBox.Text = richTextBox.Text.Insert(richTextBox.SelectionStart, dataTable.Rows[e.RowIndex]["Character"].ToString());
                richTextBox.SelectionStart = p + l;
                richTextBox.SelectionLength = 1;
            }
        }
    }
}