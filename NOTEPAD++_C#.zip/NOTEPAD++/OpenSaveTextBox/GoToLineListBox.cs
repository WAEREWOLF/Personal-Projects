﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenSaveTextBox
{
    class GoToLineListBox
    {         
        public int lineNumber { get; set; }
        public string lineText { get; set; }
        public string filePath { get; set; }
        

        public override string ToString()
        {
            return "Line " + lineNumber + ": " + lineText + "\n";
        }
    }
}
