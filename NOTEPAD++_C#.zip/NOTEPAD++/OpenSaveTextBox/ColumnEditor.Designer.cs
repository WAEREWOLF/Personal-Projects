﻿namespace OpenSaveTextBox
{
    partial class ColumnEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.repeatTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.increaseByTextBox = new System.Windows.Forms.TextBox();
            this.initialNumberTextBox = new System.Windows.Forms.TextBox();
            this.OkBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.textInsertBox = new System.Windows.Forms.TextBox();
            this.numberInsertRadio = new System.Windows.Forms.RadioButton();
            this.radioText = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // repeatTextBox
            // 
            this.repeatTextBox.Location = new System.Drawing.Point(156, 276);
            this.repeatTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.repeatTextBox.Name = "repeatTextBox";
            this.repeatTextBox.Size = new System.Drawing.Size(88, 22);
            this.repeatTextBox.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(32, 276);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 18);
            this.label3.TabIndex = 22;
            this.label3.Text = "Repeat : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(27, 234);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 18);
            this.label2.TabIndex = 21;
            this.label2.Text = "Increase by : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 199);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 18);
            this.label1.TabIndex = 20;
            this.label1.Text = "Initial number : ";
            // 
            // increaseByTextBox
            // 
            this.increaseByTextBox.Location = new System.Drawing.Point(156, 234);
            this.increaseByTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.increaseByTextBox.Name = "increaseByTextBox";
            this.increaseByTextBox.Size = new System.Drawing.Size(88, 22);
            this.increaseByTextBox.TabIndex = 19;
            this.increaseByTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.IncreaseByTextBox_KeyPress);
            // 
            // initialNumberTextBox
            // 
            this.initialNumberTextBox.Location = new System.Drawing.Point(156, 199);
            this.initialNumberTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.initialNumberTextBox.Name = "initialNumberTextBox";
            this.initialNumberTextBox.Size = new System.Drawing.Size(88, 22);
            this.initialNumberTextBox.TabIndex = 18;
            this.initialNumberTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.InitialNumberTextBox_KeyPress);
            // 
            // OkBtn
            // 
            this.OkBtn.Location = new System.Drawing.Point(246, 51);
            this.OkBtn.Margin = new System.Windows.Forms.Padding(4);
            this.OkBtn.Name = "OkBtn";
            this.OkBtn.Size = new System.Drawing.Size(128, 28);
            this.OkBtn.TabIndex = 17;
            this.OkBtn.Text = "OK";
            this.OkBtn.UseVisualStyleBackColor = true;
            this.OkBtn.Click += new System.EventHandler(this.OkBtn_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(246, 106);
            this.cancelBtn.Margin = new System.Windows.Forms.Padding(4);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(128, 28);
            this.cancelBtn.TabIndex = 16;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // textInsertBox
            // 
            this.textInsertBox.Location = new System.Drawing.Point(36, 73);
            this.textInsertBox.Margin = new System.Windows.Forms.Padding(4);
            this.textInsertBox.Name = "textInsertBox";
            this.textInsertBox.Size = new System.Drawing.Size(165, 22);
            this.textInsertBox.TabIndex = 15;
            this.textInsertBox.TextChanged += new System.EventHandler(this.textInsertBox_TextChanged);
            // 
            // numberInsertRadio
            // 
            this.numberInsertRadio.AutoSize = true;
            this.numberInsertRadio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberInsertRadio.Location = new System.Drawing.Point(31, 150);
            this.numberInsertRadio.Margin = new System.Windows.Forms.Padding(4);
            this.numberInsertRadio.Name = "numberInsertRadio";
            this.numberInsertRadio.Size = new System.Drawing.Size(155, 24);
            this.numberInsertRadio.TabIndex = 14;
            this.numberInsertRadio.Text = "Number to Insert";
            this.numberInsertRadio.UseVisualStyleBackColor = true;
            this.numberInsertRadio.CheckedChanged += new System.EventHandler(this.numberInsertRadio_CheckedChanged);
            // 
            // radioText
            // 
            this.radioText.AutoSize = true;
            this.radioText.Checked = true;
            this.radioText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioText.Location = new System.Drawing.Point(27, 39);
            this.radioText.Margin = new System.Windows.Forms.Padding(4);
            this.radioText.Name = "radioText";
            this.radioText.Size = new System.Drawing.Size(128, 24);
            this.radioText.TabIndex = 13;
            this.radioText.TabStop = true;
            this.radioText.Text = "Text to Insert";
            this.radioText.UseVisualStyleBackColor = true;
            this.radioText.CheckedChanged += new System.EventHandler(this.radioText_CheckedChanged);
            // 
            // ColumnEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(436, 416);
            this.Controls.Add(this.repeatTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.increaseByTextBox);
            this.Controls.Add(this.initialNumberTextBox);
            this.Controls.Add(this.OkBtn);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.textInsertBox);
            this.Controls.Add(this.numberInsertRadio);
            this.Controls.Add(this.radioText);
            this.Name = "ColumnEditor";
            this.Text = "ColumnEditor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox repeatTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox increaseByTextBox;
        private System.Windows.Forms.TextBox initialNumberTextBox;
        private System.Windows.Forms.Button OkBtn;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.TextBox textInsertBox;
        private System.Windows.Forms.RadioButton numberInsertRadio;
        private System.Windows.Forms.RadioButton radioText;
    }
}