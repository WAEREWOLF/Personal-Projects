﻿namespace OpenSaveTextBox
{
    internal class ClipboardHistory
    {
        public int countLineNumber;
        public string countLineText { get; set; }
        public int LineNumber { get; set; }

        public override string ToString()
        {
            return countLineText;
        }


    }
}