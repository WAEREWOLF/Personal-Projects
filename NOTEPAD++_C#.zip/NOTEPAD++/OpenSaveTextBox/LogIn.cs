﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OpenSaveTextBox
{
    public partial class LogIn : Form
    {
        public static string username;
        public LogIn()
        {
            InitializeComponent();
        }

        private void LogIn_Load(object sender, EventArgs e)
        {
            username = Environment.UserName;
            textUser.Text = username;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textUser.Text == Environment.UserName)
            {
                this.Hide();
                Form1 form = new Form1();
                form.Show();
            }
        }
    }
}
